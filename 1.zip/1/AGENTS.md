# OlmoEarth Pretrain — Agent Guide

This is a **local fork** of [allenai/olmoearth_pretrain](https://github.com/allenai/olmoearth_pretrain), extended with Chinese-region data processing pipelines (Zhejiang province), Docker-based offline deployment, and high-performance H5 conversion tooling.

> **Naming:** Project was previously code-named "Helios". The `helios/` package re-exports `olmoearth_pretrain`.

## Repository Layout

```
/                             # Workspace root
├── olmoearth_pretrain-main/  # Main package root (editable install)
│   ├── olmoearth_pretrain/   # Core Python package
│   │   ├── data/             # Dataset, dataloader, transforms, normalization, constants
│   │   ├── dataset/          # H5 conversion, sample parsing, utilities
│   │   ├── dataset_creation/ # rslearn → OlmoEarth format pipelines
│   │   ├── evals/            # Research-benchmark evaluations
│   │   ├── high_perf/        # (LOCAL) High-perf H5 conversion: task_queue, sharding, rtree_index, ramdisk
│   │   ├── internal/         # Experiment orchestration, Beaker integration, run_h5_conversion
│   │   ├── nn/               # Neural network modules (ViT, LatentMIM, tokenization)
│   │   ├── pipeline/         # (LOCAL) Shared data-processing utils: spatial, time_utils, sample_utils
│   │   ├── train/            # Training code (loss, masking, train modules, callbacks)
│   │   ├── config.py         # Unified config (olmo-core or standalone fallback)
│   │   ├── model_loader.py   # HuggingFace model loading (works without olmo-core)
│   │   └── datatypes.py      # MaskedOlmoEarthSample, MaskValue, etc.
│   ├── tests/                # Full test suite (unit + integration)
│   ├── tests_minimal_deps/   # Model-loader tests (must pass without olmo-core)
│   ├── helios/               # Backward-compat shim (deprecated, re-exports olmoearth_pretrain)
│   ├── olmoext/              # External extensions: cuttif.py, filter.py, filterproc/
│   ├── gen_data.py           # Utility: month selection, Sentinel-2 RGB resizing for data gen
│   ├── train.sh              # Example torchrun training launch command
│   └── pyproject.toml        # **THIS is the pyproject.toml that matters**
├── scripts/                  # Training + experiment scripts (OWNERS: upstream olmoearth_pretrain)
│   ├── official/             # Canonical experiment templates (base.py, nano/tiny/large variants)
│   └── tools/                # Utility scripts (sample diversity, eval minmax)
├── ht_scripts/               # (LOCAL) Data processing scripts (global LT 2.5m + Zhejiang)
│   ├── utils/                # Shared: pipeline_state, logging_config, scheduler_config, tile_index, grid_utils, zone_index
│   └── resolution_config.json # Unified resolution config (2m, 10m, 2_5m schemes)
├── docker_scripts/           # (LOCAL) Docker run helpers: run_lt_2_5m.sh, run_lt_2m.sh, run_landsat_10m.sh, run_merge2_5_to_h5.sh, run_py.sh
├── samples/                  # (LOCAL) Selected tile lists (selected_tiles_*.json), used as GRID_JSON
├── log/                      # (LOCAL) Missing/rejected/corrupt check reports (grids/, logs/)
├── LT_china.txt / LT_world.txt # (LOCAL) LT source tile lists (China / world)
├── .sisyphus/                # (LOCAL) Planning notes, drafts, run-continuation state
├── rslearnex-dev/            # (LOCAL) Nested rslearn fork with Chinese data source extensions
├── Dockerfile                # (LOCAL) Offline Docker image (conda-pack based)
├── data/                     # KML files, rslearn configs, sample data
├── dataset/                  # Dataset-level JSON configs
├── docs/                     # Markdown docs (Dataset-Creation, Pretraining, 数据生成流程, etc.)
├── pyproject.toml            # Root copy — **identical to olmoearth_pretrain-main/pyproject.toml**
└── AGENTS.md                 # This file
```

**Critical layout gotcha:** The actual Python package lives inside `olmoearth_pretrain-main/`, which has its own `pyproject.toml` and `uv.lock`. The root `pyproject.toml` is an identical copy. When running `uv sync`, work from `olmoearth_pretrain-main/`.

**Script location gotcha:** Training experiment scripts (`scripts/official/`) are at **repo root**, NOT inside `olmoearth_pretrain-main/`.

## Setup & Installation

```bash
# Full development install (from olmoearth_pretrain-main/)
cd olmoearth_pretrain-main
uv sync --locked --all-extras

# Inference-only (no olmo-core, no training deps)
uv sync --locked

# Activate venv
source .venv/bin/activate
# Or prefix with: uv run python ...
```

**Python:** 3.11–3.13 (3.12 recommended). **PyTorch:** ≥2.7, <2.8. Linux gets CUDA 12.8, non-Linux gets CPU.

**Docker (offline):** Uses conda-pack, not uv. See `Dockerfile` header for build/run instructions. Env vars: `OLMOEARTH_SRC_BASE`, `OLMOEARTH_WORK_DIR`, `OLMOEARTH_GRID_JSON`. `MKL_THREADING_LAYER=GNU` is set to avoid Intel MKL/OpenMP conflicts.

```bash
# Build (from /mnt/docer_code)
docker build -t olmoearth-pipeline:latest .

# Run (small batch test)
docker run -v /host/input:/data/input:ro -v /host/output:/data/output \
  olmoearth-pipeline:latest \
  python /app/ht_scripts/process_global_lt_2_5.py --max-samples 5
# Or via the wrapper script (mounts + env handled):
#   docker_scripts/run_lt_2_5m.sh --max-samples 5
```

## Testing

Run from `olmoearth_pretrain-main/`:

```bash
# Full suite (as CI runs it)
uv run pytest -n auto tests/

# Single test file / function
uv run pytest -vv tests/unit/nn/test_flexi_vit.py
uv run pytest -vv tests/unit/nn/test_flexi_vit.py::test_encoder_forward

# All tests for a module
uv run pytest -vv tests/unit/nn/

# Model-loader tests (with olmo-core — requires all extras)
uv run pytest -v tests_minimal_deps/

# Model-loader tests (WITHOUT olmo-core — inference-only)
uv run --extra dev pytest -v tests_minimal_deps/
```

**Test file naming:** Tests mirror the module path exactly. `olmoearth_pretrain/nn/foo.py` → `tests/unit/nn/test_foo.py`. Never place a test at `tests/unit/test_foo.py` if the source is in a subdirectory.

**Rules:** Never comment out existing tests. Never mock core functionality just to pass. Never write a "reference implementation" in tests — test real classes against each other.

## Linting & Formatting

```bash
# Run everything (as CI runs it)
pre-commit run --all-files

# Individual tools
ruff check --fix .          # Lint (Google-style docstrings D, import sorting I, pyupgrade UP)
ruff format .               # Format
mypy --ignore-missing-imports --disallow-untyped-defs .  # Type check
bandit -s B101,B311,B614 -r olmoearth_pretrain/          # Security
interrogate -vv olmoearth_pretrain --exclude 'olmoearth_pretrain/evals/models/*' --fail-under=80  # Docstring coverage
```

**Bandit skips:** B101 (assert), B311 (RNG), B614 (torch.load without weights_only) — acceptable for ML research code.

**Ruff config** (in pyproject.toml): `fix = true`, `extend-select = ["D", "I", "UP"]`, `pydocstyle.convention = "google"`.

## Config Pattern (Critical for Modifications)

All configurable components follow `@dataclass Config → .build()`:

- Configs are subclasses of `Config` (from `olmoearth_pretrain/config.py`)
- `build()` validates then constructs the object
- Use `as_dict(exclude_none=True, recurse=False)` for kwargs
- **Always subclass, never modify base config classes**
- **Config ↔ Class are tightly coupled** — changing one likely requires updating the other
- New fields on existing Config classes **must** have safe defaults (old checkpoints must still deserialize)

## Experiment Scripts

Scripts in `scripts/official/` (repo root) inject builder functions into `main()`:

| Builder | Purpose |
|---------|---------|
| `build_model_config()` | Architecture (EncoderConfig, PredictorConfig) |
| `build_train_module_config()` | Loss/optimizer (ContrastiveLatentMIM is default) |
| `build_dataset_config()` | Data source |
| `build_data_loader_config()` | Batch size, workers |
| `build_trainer_config()` | Callbacks, eval intervals |

Shared builders live in `scripts/official/script.py`. **`scripts/official/base.py` is the canonical template** — never modify it for experiments; copy to `scripts/official/ablations/`.

```bash
# Dry run to validate config
python scripts/official/base.py dry_run test_run local

# Train locally (external users must add --dataset.h5py_dir=...)
torchrun --nproc_per_node=8 scripts/official/base.py train my_run local

# CLI overrides use dotlist: --model.encoder_config.depth=24
```

**Model size presets** (`olmoearth_pretrain/internal/utils.py` → `MODEL_SIZE_ARGS`, 17 presets):
`nano`, `tiny`, `tiny_more_heads`, `base`, `large`, `giga`, plus `_shallow_decoder` and `_super_shallow_decoder` variants of each. Dedicated launch scripts exist: `scripts/official/{nano,tiny,base,large}_launch.sh`.

## Key Training Architecture

- **Masking:** `MaskingConfig` in `olmoearth_pretrain/train/masking.py` — runs in dataloader workers (CPU)
- **Train modules:** `olmoearth_pretrain/train/train_module/` — `ContrastiveLatentMIMTrainModule` (default), `LatentMIMTrainModule`, `MAETrainModule`, `GalileoTrainModule`
- **Model:** `olmoearth_pretrain/nn/flexihelios.py` (EncoderConfig/PredictorConfig), `latent_mim.py` (LatentMIMConfig), `flexi_vit.py` (flexible ViT backbone)
- **Callbacks:** `olmoearth_pretrain/train/callbacks/` — DownstreamEvaluatorCallback, OlmoEarthWandBCallback, MetricSaverCallback
- **Modality definitions:** `olmoearth_pretrain/data/constants.py` → `Modality` class with `ModalitySpec` instances

## Dataset Creation (Seven-Step Pipeline)

1. **Create samples** — spatial/temporal sampling strategy
2. **Create windows** — rslearn windows from lon/lat lists
3. **Prepare data** — `rslearn dataset prepare`
4. **Ingest data** — `rslearn dataset ingest`
5. **Materialize** — `rslearn dataset materialize`
6. **Convert to OlmoEarth format** — per-modality converters in `dataset_creation/rslearn_to_olmoearth/`
7. **Convert to H5** — `run_h5_conversion` for training-optimized storage

**Adding a new modality:** Register in `Modality` class (`data/constants.py`), create converter in `dataset_creation/rslearn_to_olmoearth/`, ensure metadata CSVs are emitted and summarized via `make_meta_summary`.

**H5 structure:** Each sample file contains `latlon` (float32 `[lat,lon]`), `timestamps` (int `[T,3]` = `[day,month,year]`), per-modality datasets, `missing_timesteps_masks/<modality>` (bool `[T]`).

## Local Extensions (Zhejiang Data Processing)

This fork adds significant local tooling for processing Chinese-region satellite data:

- **`ht_scripts/`** (repo root) — Data processing scripts. Main entrypoints:
  - **Pipeline (steps 1–6):** `process_global_lt_2_5.py` (global LT 2.5m, multi-UTM), `process_merged_sar_2_5_global.py` (merged SAR 2.5m, ramdisk two-stage), `process_zhejiang_lt_2.py` (Zhejiang LT 2m), `process_zhejiang_landsat_10_fast.py` (Landsat 10m)
  - **Step 7 (H5):** `merge2_5_to_h5.py` (2.5m, supports `--task-queue` multi-node and `--shard-count`)
  - **GHS-POP 人口切分（一次性任务）:** `process_ghsl_pop_zhejiang.py` (JRC GHS-POP → Zhejiang grid 两级切分：gdalwarp 裁剪重投影 UTM50/10m + ×0.01 总量守恒缩放（仅有效像元，nodata 保留）→ 网格切 4×128×128 sample → 切 1024×4×4 subsample；`--tile-start/--tile-end` 分片), 分布式调度 `distributed_ghsl_pop_zhejiang.py` (SSH + Docker, 连续区间分片)
  - **Distributed schedulers** (coordinator → SSH → workers, Docker via `run_py.sh`): `distributed_lt_2_5_pipeline.py` (two-stage prepare/consume), `distributed_merge_25_26.py` (2025+2026 → 15-month merge), `distributed_missing_check.py`, `distributed_corrupt_check.py`, `distributed_rename_grids.py` (EPSG_xxx → EPSG:xxx), `qc_distributed.py` + `qc_worker.py`
  - **Workers / helpers:** `merge_25_26_worker.py`, `rename_grids_worker.py`, `check_corrupt_outputs.py` (0-byte TIF/CSV scan, scan/worker modes), `merge_lt_2_5_manifests.py`
  - **Utilities** (`ht_scripts/utils/`): `pipeline_state.py`, `logging_config.py`, `scheduler_config.py`, `tile_index.py`, `grid_utils.py`, `zone_index.py`, `resource_monitor.py`, `source_path_resolver.py`, `check_zero_missing_ratio.py`, `extract_bad_bands.py`, `convert_2_5m_to_10m_tiles.py`, `merge_to_15month.py`, `trim_24month_to_15.py`, `rename_tif_to_official.py`, `verify_rejected_samples.py`, `rejected_tiles_to_shp.py`, `tif_to_shp_footprints.py`, `analyze_2026_coverage.py`, `deploy_docker_image.sh`
- **`olmoearth_pretrain/high_perf/`** — High-performance H5 conversion: task_queue (parallel block processing), sharding, rtree_index, ramdisk utilities
- **`olmoearth_pretrain/pipeline/`** — Shared utilities: `spatial.py`, `time_utils.py`, `sample_utils.py`
- **`olmoext/`** (`olmoearth_pretrain-main/olmoext/`) — External extensions: `cuttif.py`, `filter.py`, `filterproc/bat.py` (data filtering and batched processing)
- **`rslearnex-dev/`** — Nested rslearn fork (`rslearnex-dev/rslearnex-dev/`) with Chinese data source extensions
- **`scripts/tools/`** — Utilities: sample diversity analysis, eval dataset minmax computation

**Data-processing script convention:** Scripts must keep a **Chinese-language header** with: processing target (处理对象), resolution system (分辨率体系), input/output directories (输入/输出目录), sample/window rules (样本/窗口规则), time-series rules (时间序列规则), seven-step flow (七步流程), common commands (常用命令), key CLI parameters (关键 CLI 参数).

**nodata handling (local specifics):** Key: `srtm`/`landcover`/`worldcover` use `nodata=0`, `sentinel1`/`sentinel2_l2a`/`landsat`/`worldcereal` have `nodata=None`. SAR merged data uses `uint8` with `nodata=0`. The H5 conversion uses `MISSING_VALUE=-99999` (defined in `data/constants.py`) for masked pixels. Float32 `NaN` silently coerces to 0 during `astype(np.uint8)` — SAR scripts add NaN safety checks.

**Resolution config:** `ht_scripts/resolution_config.json` defines three schemes: `10m`, `2m`, `2_5m`. Set via env var `OLMOEARTH_RESOLUTION_SCHEME`. Per `data/constants.py`, `OLMOEARTH_CONFIG` env var points to a JSON resolution config.

## GPU Sync Point Warnings

In training code, avoid these in hot loops:
- `tensor.item()` — CPU sync
- Boolean indexing `x[mask]` — triggers `nonzero()` + sync
- `if tensor.any():` without `.item()`

## Code Style Summary

- **Google-style docstrings** (ruff rule D)
- **Import sorting** (ruff rule I)
- **Docstring coverage ≥80%** for `olmoearth_pretrain/` (excluding `evals/models/`)
- Prefer `list`, `dict`, `tuple` over `typing.List`, `typing.Dict`, `typing.Tuple`
- `if x is not None` over `if x` when `None` vs falsy matters
- Named args over positional for calls with 3+ args
- No list comprehensions spanning 3+ logical operations — break into a loop
- Class names say what they are, not how they differ from a base
- Test function names say what they test: `test_unmask_preserves_token_order` not `test_unmock`

## CI (GitHub Actions)

Triggered on push/PR to `main` branch:

| Workflow | Trigger | What it runs |
|----------|---------|-------------|
| `tests.yaml` | push + PR to main | Full suite (`uv run pytest -n auto tests/`), inference-only (`uv run --extra dev pytest -v tests_minimal_deps/`) |
| `lint.yaml` | PR to main | `pre-commit run --all-files` (ruff, mypy, bandit, interrogate) |
| `publish.yml` | — | PyPI publishing |
| `labeler.yaml` | PR to main | Auto-label PRs |
| `daily-experiment-report.yaml` | schedule | Generates experiment reports |

Install in CI: `uv sync --locked --all-extras` (full), `uv sync --extra dev --no-install-project && uv tool install pre-commit` (lint). uv version pin: `0.9.5`.

## Collaboration Rules for Agents

### General Principles

1. **Minimize scope.** Do not expand beyond what was asked. Verify: goal, allowed files, logic to preserve, impact on existing modalities/pipeline.
2. **Code is the source of truth.** Not README, comments, or Q&A docs. Must read code to confirm behavior for: time-series batching, monthly slot semantics, metadata timestamps, nodata/NaN/0 handling, rslearn step behavior, H5 masks, placeholder images.
3. **Respect existing dirty state.** Run `git status --short` first. Don't revert/format/commit unrelated files. Commit with explicit paths: `git commit -- file1 file2`.
4. **Do not modify without request:** official core defaults, unrelated modality scripts, pre-existing dirty files.
5. **NEVER execute scripts that touch production data without explicit permission.** Writing code/scripts ≠ running them. Any command that reads or writes to `/mnt/qh2-nas2/` or `/mnt/qh2-nas3/` requires the user to explicitly say "执行" or "运行" before it can be invoked. Scripts must be delivered for review first, then executed only on explicit instruction.

### Guardrails Against Requirement Drift (防跑偏规则)

These rules complement the General Principles above. They exist because large models can silently deviate from the user's actual intent while producing plausible-looking code. Follow them on **every** non-trivial coding task.

#### 1. Restate Before You Code (复述约束)

Before writing or editing any code, restate the user's request in your own words and list:

- **Core goal**: What exactly must be achieved?
- **Files to touch**: Which files must be modified? Which are read-only reference?
- **Forbidden changes**: Which files, functions, or defaults must **not** be touched, even if they look related?
- **Edge cases & constraints**: nodata handling, CRS transforms, time-filling inheritance, fallback values, backward compatibility (old checkpoints must still deserialize), etc.

Wait for the user to confirm or correct your restatement before proceeding. If the user says "Go ahead" or "开始", that counts as confirmation.

#### 2. Mandatory Change Summary (强制变更摘要)

After completing edits and **before** declaring the task done, output a structured summary:

| File | What changed | Why | Risk of side effects |
|------|-------------|-----|---------------------|
| `foo.py` | Removed `paths[0]` fallback | Use real source path from rslearn | Low — only affects metadata CSV |

If the table shows any file you were **not** explicitly asked to modify, explain why. If you cannot justify it, revert that change.

#### 3. Self-Critique Before Hand-off (自我审查)

Right before the final response, role-play a **code reviewer** and answer honestly:

1. "Does any part of this change violate the original requirement?"
2. "Were unnecessary files or functions modified?"
3. "Is the implementation over-engineered or under-engineered for the stated goal?"
4. "If the user re-runs the same pipeline tomorrow, will the behavior match their expectation?"

If any answer is negative, fix the issue before delivering the result. Do not bury known problems in a footnote.

### Validation After Changes

```bash
python -m py_compile <changed_files>
python <entry_script> --help
```

For data-processing changes, also verify: rslearn config valid, OlmoEarth CSVs produced, metadata time fields correct, H5 timestamps/masks match.

If you did **not** run the full pipeline, state that explicitly.

### Seven-Step Pipeline Convention

Keep steps in dedicated functions: `step1_create_samples`, `step2_create_windows`, ... `step7_convert_to_h5`. Do **not** implicitly execute multiple steps inside one function.

### Configuration vs. Logic Separation

Paths, resolutions, worker counts, batch sizes, modality lists → CLI args (`argparse`/`typer`), JSON/YAML config, or constants block at top of file. Avoid hard-coding deep inside logic.

### Reuse Common Logic

Extract shared utilities for: month discovery, time boundary calculation, rslearn command execution, logging, H5 lat/lon override, pipeline state management. But **don't refactor during urgent bug fixes** — commit refactors separately.

### Git Commit Rules

1. `git status --short`
2. Stage only task-related files
3. Concise commit message describing behavioral change
4. `git status --short` again
5. Report commit hash + remaining unstaged changes

### Final Response Format

State: what changed, which files, which functions/parameters, what validation was done, commit hash (if made), remaining risks. Never reply with only "已完成" or "Done".

## OpenCode `task()` 反模式警告

> ⚠️ **禁止使用 `task(run_in_background=true)` 启动子 agent 并期望通过 `background_output()` 获取结果。**

**根因**：`task()` 的子 agent 运行在**独立 session** 中（`task_metadata` 中的 `session_id` 即为子 session），与主 session 的 `background_output` 注册表完全隔离。子 session 在 agent 完成后会被系统自动清理，导致结果永久丢失。

**已验证的行为矩阵**：

| 子 agent 状态 | `task_id` 继续 | `background_output` | 实际可用性 |
|-------------|---------------|---------------------|-----------|
| running     | ✅ 可继续      | ❌ Task not found    | 无意义——结果未产出 |
| completed   | ❌ Task not found | ❌ Task not found | 结果存在但不可达 |

**正确用法**：

```python
# ✅ 正确：同步阻塞，结果直接返回到当前上下文
result = task(subagent_type="librarian", run_in_background=false, ...)

# ✅ 正确：多子 agent 并行时，用 session_read 在 completed 通知后立即读取
task(subagent_type="explore", run_in_background=true, ...)
# 收到 <system-reminder> 后：
session_read(session_id="ses_xxx", include_tool_results=true, limit=200)

# ❌ 错误：run_in_background=true 后调用 background_output——两套系统不互通
task(subagent_type="librarian", run_in_background=true, ...)
# 收到通知后：
background_output(task_id="bg_xxx")  # → Task not found
```

**2026-06-10 验证记录**：7 个 `librarian`/`explore` 子 agent（bg_690cbf17 等）全部通过 `background_output` 返回 `Task not found`。子 session 已从 `session_list` 中消失。

**2026-06-10 v1.17.0 复测**：Bug **仍未修复**。`background_output` 依旧返回 `Task not found`。`session_read(session_id=..., include_tool_results=true)` 是目前唯一可靠的取结果方式。

---

## Quick Reference

```bash
# Install
cd olmoearth_pretrain-main && uv sync --locked --all-extras

# Tests (full suite)
uv run pytest -n auto tests/

# Tests (single file/function)
uv run pytest -vv tests/unit/nn/test_flexi_vit.py::test_encoder_forward

# Lint
pre-commit run --all-files

# Validate training config (scripts at repo root)
python scripts/official/base.py dry_run test_run local

# Train locally
torchrun --nproc_per_node=8 scripts/official/base.py train my_run local --dataset.h5py_dir=/path/to/h5

# Inference (works without olmo-core)
uv run python -c "from olmoearth_pretrain.model_loader import load_model_from_id, ModelID; print(load_model_from_id(ModelID.OLMOEARTH_V1_BASE))"

# Docker run (small batch test)
docker run -v /host/input:/data/input:ro -v /host/output:/data/output \
  olmoearth-pipeline:latest \
  python /app/ht_scripts/process_global_lt_2_5.py --max-samples 5

# Data generation utility
python gen_data.py --help  # from olmoearth_pretrain-main/
```
