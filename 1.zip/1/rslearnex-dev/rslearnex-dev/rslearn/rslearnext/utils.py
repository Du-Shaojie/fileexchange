import re
from datetime import datetime
from typing import Optional, Dict


def fetch_fn_info(filename: str, template: str) -> Optional[Dict[str, str]]:
    """
    更简单的实现：从文件名提取所有占位符的值
    """
    # 将占位符替换为正则表达式
    # 先转义整个模板
    escaped = re.escape(template)
    
    # 然后替换转义后的占位符
    # 查找所有 {name} 格式的占位符
    placeholder_matches = list(re.finditer(r'\\\{([^}]+)\\\}', escaped))
    
    if not placeholder_matches:
        return None
    
    # 构建正则表达式
    regex_parts = []
    last_end = 0
    
    for match in placeholder_matches:
        # 添加占位符前的文本
        if match.start() > last_end:
            regex_parts.append(escaped[last_end:match.start()])
        
        # 添加命名捕获组
        group_name = match.group(1)
        regex_parts.append(f"(?P<{group_name}>.+?)")
        
        last_end = match.end()
    
    # 添加剩余部分
    if last_end < len(escaped):
        regex_parts.append(escaped[last_end:])
    
    # 组合正则表达式
    regex_pattern = "^" + "".join(regex_parts) + "$"
    
    # 匹配
    pattern = re.compile(regex_pattern)
    match = pattern.match(filename)
    
    return match.groupdict() if match else None


# 使用示例
if __name__ == "__main__":
    # 简单测试
    test_cases = [
        ("S2_ningbo-nocloud2025_01_10m-0000000333-0000001786.tif", 
         "S2_{region}-nocloud{time}_10m-{start}-{end}.tif"),
        ("S2_shanghai-nocloud2025_03_10m-0000000000-0000000030.tif", 
         "S2_{region}-nocloud{time}_10m-{start}-{end}.tif"),
        ("LANDSAT_LC08_L1TP_118038_20250115_20250115_02_T1_B4.TIF", 
         "LANDSAT_LC08_L1TP_{path}_{time}_{time2}_{collection}_T1_B{band}.TIF"),
    ]
    
    for filename, template in test_cases:
        print(f"\n文件名: {filename}")
        print(f"模板: {template}")
        result = fetch_fn_info(filename, template)
        print(f"结果: {result}")