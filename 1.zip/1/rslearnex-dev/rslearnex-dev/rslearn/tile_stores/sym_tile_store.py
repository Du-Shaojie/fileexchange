import os
from upath import UPath
from .default import COMPLETED_FNAME, DefaultTileStore

class SymLinkTileStore(DefaultTileStore):
    """
    直接使用软链接构建tiles, 适合本身就是已经是tiles结构的tif文件。
    """

    def write_raster_file(
        self, layer_name: str, item_name: str, bands: list[str], fname: UPath
    ) -> None:
        """Write raster data to the store.

        Args:
            layer_name: the layer name or alias.
            item_name: the item to write.
            bands: the list of bands in the array.
            fname: the raster file, which must be readable by rasterio.
        """
        raster_dir = self._get_raster_dir(layer_name, item_name, bands, write=True)
        raster_dir.mkdir(parents=True, exist_ok=True)
        
        # Just copy the file directly.
        dst_fname = raster_dir / fname.name
        # create symbollink
        os.symlink(fname, dst_fname)

        (raster_dir / COMPLETED_FNAME).touch()