import re
from typing import Optional, Dict

import hashlib
import random
from datetime import datetime, timedelta, UTC


def pick_time_from_default_range(
    filename: str,
    default_time_range: dict[str, str],
) -> datetime:
    """
    在 default_time_range 内，为当前文件选一个稳定随机时间。
    同一个文件名每次得到同一个时间，便于复现。
    """
    range_fmt = default_time_range.get("time_fmt", "%Y-%m-%d")

    start = datetime.strptime(default_time_range["start"], range_fmt).replace(tzinfo=UTC)
    end = datetime.strptime(default_time_range["end"], range_fmt).replace(tzinfo=UTC)


    if end < start:
        raise ValueError(f"default_time_range end {end} is earlier than start {start}")

    total_seconds = int((end - start).total_seconds())
    if total_seconds == 0:
        return start

    seed = int(hashlib.md5(filename.encode("utf-8")).hexdigest(), 16) % (2**32)
    rng = random.Random(seed)
    offset = rng.randint(0, total_seconds)
    return start + timedelta(seconds=offset)


def resolve_time_from_filename(
    filename: str,
    fn_template: str | None,
    time_key: str | None,
    time_fmt: str | None,
    default_time_range: dict[str, str] | None,
    fn_regex: str | None = None,
) -> datetime:
    """
    优先从文件名解析时间。
    若未配置文件名解析规则，或解析失败，则回退到 default_time_range。
    fn_regex 优先级高于 fn_template，适用于文件名中有固定位置时间字段的情况，
    例如 fn_regex="(?P<time>\\d{8})F\\.tif$" 可从 GFL1LAS...20251007F.tif 提取 20251007。
    """
    if fn_regex and time_key and time_fmt:
        m = re.search(fn_regex, filename)
        if m is not None:
            groups = m.groupdict()
            if time_key in groups:
                try:
                    return datetime.strptime(groups[time_key], time_fmt).replace(tzinfo=UTC)
                except Exception:
                    pass

    if fn_template and time_key and time_fmt:
        info = fetch_fn_info(filename, fn_template)
        if info is not None and time_key in info:
            try:
                return datetime.strptime(info[time_key], time_fmt).replace(tzinfo=UTC)
            except Exception:
                pass
    
    if default_time_range is not None:
        return pick_time_from_default_range(filename, default_time_range)
    else:
        return None

def fetch_fn_info(filename: str, template: str) -> Optional[Dict[str, str]]:
    """
    从文件名提取所有占位符的值
    支持格式: {var} 或 {var:8} 其中8表示占位符的长度
    """
    # 将占位符替换为正则表达式
    # 先转义整个模板
    escaped = re.escape(template)
    
    # 然后替换转义后的占位符
    # 查找所有 {name} 或 {name:length} 格式的占位符
    placeholder_matches = list(re.finditer(r'\\\{([^}:]+)(?::(\d+))?\\\}', escaped))
    
    if not placeholder_matches:
        return None
    
    # 构建正则表达式
    regex_parts = []
    last_end = 0
    
    for match in placeholder_matches:
        # 添加占位符前的文本
        if match.start() > last_end:
            regex_parts.append(escaped[last_end:match.start()])
        
        # 提取变量名和可选的长度
        group_name = match.group(1)
        length_spec = match.group(2)
        
        # 如果指定了长度，使用精确长度匹配
        if length_spec:
            regex_parts.append(f"(?P<{group_name}>.{{{length_spec}}})")
        else:
            regex_parts.append(f"(?P<{group_name}>.+?)")
        
        last_end = match.end()
    
    # 添加剩余部分
    if last_end < len(escaped):
        regex_parts.append(escaped[last_end:])
    
    # 组合正则表达式
    regex_pattern = "^" + "".join(regex_parts) + "$"
    
    # 匹配
    pattern = re.compile(regex_pattern)
    match = pattern.match(filename)
    
    return match.groupdict() if match else None


# 使用示例
if __name__ == "__main__":
    # 简单测试
    test_cases = [
        ("S2_ningbo-nocloud2025_01_10m-0000000333-0000001786.tif", 
         "S2_{region}-nocloud{time}_10m-{start}-{end}.tif"),
        ("S2_shanghai-nocloud2025_03_10m-0000000000-0000000030.tif", 
         "S2_{region}-nocloud{time}_10m-{start}-{end}.tif"),
        ("LANDSAT_LC08_L1TP_118038_20250115_20250115_02_T1_B4.TIF", 
         "LANDSAT_LC08_L1TP_{path}_{time}_{time2}_{collection}_T1_B{band}.TIF"),
         ("Test11803820250115F_guess.TIF", 
         "Test{num:6}{time}F{test}.TIF"),
    ]
    
    for filename, template in test_cases:
        print(f"\n文件名: {filename}")
        print(f"模板: {template}")
        result = fetch_fn_info(filename, template)
        print(f"结果: {result}")