"""Data source for raster or vector data in local files."""

import functools
import json
from typing import Any, Generic, TypeVar
from datetime import datetime, timezone, UTC

from rasterio.crs import CRS
from upath import UPath
import shapely

from rslearn.config.dataset import QueryConfig, RasterLayerConfig
from rslearn.data_sources.data_source import Item
from rslearn.config import LayerConfig
from rslearn.log_utils import get_logger
from rslearn.tile_stores import TileStoreWithLayer
from rslearn.utils.feature import Feature
from rslearn.utils.fsspec import get_upath_local, join_upath, open_rasterio_upath_reader
from rslearn.utils.geometry import Projection, STGeometry, get_global_geometry
from rslearn.data_sources.local_file_utils import resolve_time_from_filename
from rslearn.data_sources.local_files import (
    _ImporterRegistry,
    Importer,
    Importers,
    LocalFiles,
    RasterImporter,
    RasterItem,
    RasterItemSpec,
    VectorImporter,
)

logger = get_logger("__name__")

Importers = _ImporterRegistry()

# 暂不涉及矢量数据修改，直接显示调用
Importers["vector"] = VectorImporter


def resolve_band_names(
    src_count: int,
    band_names_alias: list[str] | None = None,
) -> list[str]:
    """
    根据配置解析最终 band 名。

    规则：
    1. 如果 band_names_alias 为 None，则默认返回 B1, B2, ..., Bn
    2. 如果 band_names_alias 长度 >= src_count，则截取前 src_count 个
    3. 如果 band_names_alias 长度 < src_count，则前面的按配置使用，
       剩余的自动补成 others1, others2, ...
    """
    if band_names_alias is None:
        return [f"B{i + 1}" for i in range(src_count)]

    if not isinstance(band_names_alias, list):
        raise TypeError("band_names_alias must be a list[str] or None")

    resolved = list(band_names_alias[:src_count])

    missing_num = src_count - len(resolved)
    if missing_num > 0:
        resolved.extend([f"others{i + 1}" for i in range(missing_num)])

    return resolved


@Importers.register("raster")
class RasterImporterEx(RasterImporter):
    """
    An Importer for raster data.
    增强版，以适配自定数据
    """

    def list_items(self, config: LayerConfig, src_dir: UPath) -> list[RasterItem]:
        """Extract a list of Items from the source directory.

        Args:
            config: the configuration of the layer.
            src_dir: the source directory.
        """
        item_specs: list[RasterItemSpec] = []

        if config.data_source is None:
            raise ValueError("RasterImporterEx requires data_source config")

        conf_dict = config.data_source.config_dict

        fn_template = conf_dict.get("fn_template")
        time_key = conf_dict.get("time_key", "time")
        time_fmt = conf_dict.get("time_fmt")

        default_time_range = conf_dict.get("default_time_range")
        band_names_alias = conf_dict.get("band_names_alias")

        # See if user has provided the item specs directly.
        if "item_specs" in conf_dict:
            for spec_dict in conf_dict["item_specs"]:
                spec = RasterItemSpec.from_config(src_dir, spec_dict)
                item_specs.append(spec)
        else:
            # Otherwise we need to list files and assume each one is separate.
            file_paths = src_dir.glob("**/*.tif")
            for path in file_paths:
                # Ignore JSON files.
                if path.name.endswith(".json"):
                    continue

                # Ignore temporary files that may be created by open_atomic.
                # The suffix should be like "X.tif.tmp.1234".
                parts = path.name.split(".")
                if len(parts) >= 4 and parts[-2] == "tmp" and parts[-1].isdigit():
                    continue

                spec = RasterItemSpec(fnames=[path], bands=None)
                item_specs.append(spec)

        items = []
        for spec in item_specs:
            # Get geometry from the first raster file.
            # We assume files are readable with rasterio.
            with open_rasterio_upath_reader(spec.fnames[0]) as src:
                # 增加根据文件名对 time_range 的解析
                cvt_time = resolve_time_from_filename(
                    filename=spec.fnames[0].name,
                    fn_template=fn_template,
                    time_key=time_key,
                    time_fmt=time_fmt,
                    default_time_range=default_time_range,
                )
                cvt_time_range = (cvt_time, cvt_time)

                crs = src.crs
                left = src.transform.c
                top = src.transform.f
                # Resolutions in projection units per pixel.
                x_resolution = src.transform.a
                y_resolution = src.transform.e
                start = (int(left / x_resolution), int(top / y_resolution))
                shp = shapely.box(
                    start[0], start[1], start[0] + src.width, start[1] + src.height
                )
                projection = Projection(crs, x_resolution, y_resolution)
                geometry = STGeometry(projection, shp, cvt_time_range)

                # 自动补 band 名
                if spec.bands is None:
                    resolved_bands = resolve_band_names(
                        src_count=src.count,
                        band_names_alias=band_names_alias,
                    )
                    spec = RasterItemSpec(
                        fnames=spec.fnames,
                        bands=[resolved_bands],
                        name=spec.name,
                    )

            if geometry.is_too_large():
                geometry = get_global_geometry(time_range=cvt_time_range)
                logger.warning(
                    "Global geometry detected: this geometry will be matched against all "
                    "windows in the rslearn dataset. When using settings like "
                    "max_matches=1 and space_mode=MOSAIC, this may cause windows outside "
                    "the geometry’s valid bounds to be materialized from the global raster "
                    "instead of a more appropriate source. Consider using COMPOSITE mode, "
                    "or increasing max_matches if this behavior is unintended."
                )

            if spec.name:
                item_name = spec.name
            else:
                item_name = spec.fnames[0].stem

            logger.debug(
                "RasterImporter.list_items: got bounds of %s: %s", item_name, geometry
            )
            items.append(RasterItem(item_name, geometry, spec))

        logger.debug("RasterImporter.list_items: discovered %d items", len(items))
        return items


class LocalFilesEx(LocalFiles):
    """A data source for ingesting data from local files."""

    def __init__(
        self,
        config: LayerConfig,
        src_dir: UPath,
    ) -> None:
        """Initialize a new LocalFiles instance.

        Args:
            config: configuration for this layer.
            src_dir: source directory to ingest
        """
        self.config = config
        self.importer = Importers[config.layer_type.value]()
        self.src_dir = src_dir

    @staticmethod
    def from_config(config: LayerConfig, ds_path: UPath) -> "LocalFilesEx":
        """Creates a new LocalFiles instance from a configuration dictionary."""
        if config.data_source is None:
            raise ValueError("LocalFiles data source requires a data source config")
        d = config.data_source.config_dict
        return LocalFilesEx(config=config, src_dir=join_upath(ds_path, d["src_dir"]))