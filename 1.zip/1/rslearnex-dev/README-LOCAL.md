# rslearnex-dev — OlmoEarth 数据处理管线依赖说明

> **位置**: `/mnt/qh2-nas3/00-data/00-dusj/olmoearth_code/rslearnex-dev/`  
> **性质**: rslearn 的本地 fork + 扩展版本  
> **版本**: v0.0.11  
> **用途**: OlmoEarth 七步数据处理流水线的上游依赖库

---

## 1. 为什么保留这个目录

`rslearnex-dev/` **不可删除**，它是 OlmoEarth 训练数据准备的底层引擎。OlmoEarth 的七步数据流水线：

```
1. create_samples  →  2. create_windows  →  3. prepare
      ↓
4. ingest  →  5. materialize  →  6. convert_to_OlmoEarth  →  7. H5_conversion
```

第 2~5 步完全依赖 rslearn 的 **Dataset / Window / Layer / DataSource** 架构实现。没有 rslearn，整个数据处理管线将无法运行。

---

## 2. 模块结构

```
rslearnex-dev/
├── rslearn/                  # 核心库（ OlmoEarth 直接 import 的模块）
│   ├── config/               # 数据集/模型配置解析
│   ├── dataset/              # Dataset, Window, Layer, Index, Materialize
│   ├── data_sources/         # 28+ 遥感数据源接入
│   ├── models/               # 30+ 遥感基础模型封装
│   ├── train/                # 训练框架（任务、transform、callback）
│   ├── tile_stores/          # 瓦片存储后端
│   ├── utils/                # 通用工具
│   └── rslearnext/           # 🏷️ 本地扩展（中文数据文件名解析）
├── tests/                    # 单元测试 + 集成测试
├── docs/                     # 官方文档
├── design/workflows/         # 设计文档（GeotiffInference, SolarFarms 等）
└── pyproject.toml            # 包配置（name=rslearn, version=0.0.11）
```

---

## 3. 关键子模块详解

### 3.1 `rslearn/dataset/` — 数据组织核心

定义了 rslearn 的核心抽象：

| 类/模块 | 作用 |
|---------|------|
| `Dataset` | 数据集根对象，管理 layers、windows、tile_store |
| `Window` | 时空采样窗口（训练样本的空间/时间边界） |
| `Layer` | 数据层（Sentinel-2、Landcover、SRTM 等） |
| `DatasetIndex` | 空间索引（R-tree），加速窗口与数据的匹配 |
| `materialize.py` | 将数据从数据源 materialize 到本地瓦片存储 |

OlmoEarth 的 `create_windows` 和 `materialize` 步骤直接调用这里的逻辑。

### 3.2 `rslearn/data_sources/` — 多源数据接入（28+ 数据源）

支持从以下数据源自动下载、裁剪、重投影数据到 Window：

| 数据源 | 文件 | 数据类型 |
|--------|------|---------|
| Sentinel-2 L1C/L2A | `gcp_public_data.py`, `planetary_computer.py` | 光学影像 |
| Sentinel-1 | `aws_sentinel1.py` | SAR |
| Landsat 8/9 | `usgs_landsat.py`, `aws_landsat.py` | 光学影像 |
| SRTM 高程 | `earthdata_srtm.py` | DEM |
| OpenStreetMap | `openstreetmap.py` | 矢量/栅格 |
| WorldCover | `worldcover.py` | 土地覆盖 |
| WorldCereal | `worldcereal.py` | 作物分类 |
| USDA CDL | `usda_cdl.py` | 美国作物数据 |
| Planet Labs | `planet.py`, `planet_basemap.py` | 商业卫星 |
| Google Earth Engine | `google_earth_engine.py` | GEE 导出数据 |
| 本地 GeoTIFF | `geotiff.py`, `local_files.py` | 本地栅格 |
| EuroCrops | `eurocrops.py` | 欧洲作物 |
| … | 共 28 个 Python 文件 | … |

### 3.3 `rslearn/models/` — 遥感基础模型集成（30+ 模型）

封装了主流遥感基础模型，支持在 rslearn 训练框架中直接调用：

| 模型 | 文件/目录 |
|------|----------|
| **OlmoEarth** | `olmoearth_pretrain/` ← 本项目的模型 |
| AnySat | `anysat.py` |
| Clay | `clay/` |
| Copernicus FM | `copernicusfm.py`, `copernicusfm_src/` |
| Croma | `croma.py` |
| DINOv3 | `dinov3.py` |
| Galileo | `galileo/` |
| Panopticon | `panopticon.py`, `panopticon_data/` |
| Presto | `presto/` |
| Prithvi | `prithvi.py` |
| SatlasPretrain | `satlaspretrain.py` |
| SSL4EO-S12 | `ssl4eo_s12.py` |
| TerraMind | `terramind.py` |
| … | 共 30+ 个模型定义 |

### 3.4 `rslearn/train/` — 训练框架

| 子目录 | 内容 |
|--------|------|
| `tasks/` | 任务定义：classification, segmentation, detection, regression, multi_task |
| `transforms/` | 数据变换：normalize, mask, flip, crop, pad, select_bands, sentinel1 等 |
| `callbacks/` | Lightning Callback：评估、可视化等 |

### 3.5 `rslearn/rslearnext/` — 🏷️ 本地扩展

**这是 OlmoEarth 本地添加的扩展模块**，目前包含：

- **`utils.py`** — 中文数据文件名解析工具
  - 功能：`fetch_fn_info(filename, template)` 从文件名按模板提取 `region`, `time`, `start`, `end` 等字段
  - 用途：解析浙江数据处理流程中 `S2_{region}-nocloud{time}_10m-{start}-{end}.tif` 这类中文区域数据的文件名

---

## 4. 与 OlmoEarth 的调用关系

```
OlmoEarth 数据处理脚本（ht_scripts/）
         │
         ▼
    import rslearn
         │
         ├──► rslearn.dataset.Dataset       (创建/管理数据集)
         ├──► rslearn.dataset.Window        (定义时空窗口)
         ├──► rslearn.data_sources.*        (接入 Sentinel-2/Landsat/SRTM 等)
         ├──► rslearn.dataset.materialize   (数据物化)
         └──► rslearnext.utils.fetch_fn_info (解析中文文件名)
```

---

## 5. 规模统计

| 指标 | 数值 |
|------|------|
| Python 文件数 | 398 个 |
| Python 代码行数 | ~8.4 万行 |
| 估算 Token 数 | ~75万 ~ 86万 |
| 目录总大小 | 6.3 MB |
| 占整个项目 Python 代码比例 | ~75%（行数） |

> ⚠️ **注意**：rslearnex-dev/ 是项目最大的单一模块，占整个代码库约 3/4 的 Python 代码量。但它属于**上游依赖**，日常开发中**不需要修改其内部代码**。

---

## 6. 什么时候需要动这个目录

| 场景 | 是否需要修改 rslearnex-dev/ |
|------|---------------------------|
| 添加新的遥感数据源 | ✅ 需要在 `data_sources/` 新增接入模块 |
| 修改数据处理窗口逻辑 | ✅ 可能涉及 `dataset/` 的 Window/Layer |
| 调整训练任务类型 | ✅ 涉及 `train/tasks/` |
| 日常训练/推理 | ❌ 不需要 |
| 修改 OlmoEarth 模型结构 | ❌ 在 `olmoearth_pretrain/` 修改 |
| 新增评估指标 | ❌ 在 `olmoearth_pretrain/evals/` 修改 |

---

## 7. 安装

```bash
cd rslearnex-dev/rslearnex-dev
pip install -e ".[extra]"
```

或直接作为 OlmoEarth 依赖的一部分安装（已在 `olmoearth_pretrain-main/pyproject.toml` 中声明）。

---

## 8. 相关文档

- `rslearnex-dev/rslearnex-dev/docs/CoreConcepts.md` — rslearn 核心概念
- `rslearnex-dev/rslearnex-dev/docs/DatasetConfig.md` — 数据集配置文件格式
- `rslearnex-dev/rslearnex-dev/docs/ModelConfig.md` — 模型配置文件格式
- `rslearnex-dev/rslearnex-dev/docs/Examples.md` — 使用示例
